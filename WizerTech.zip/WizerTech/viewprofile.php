
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        <link type="text/css" rel="stylesheet" href="css/mystylesheet.css"/>


    <title>View profile page</title>
</head>
<body class="bg-dark text-center">
<?php include 'Extra/navbar.php'; ?>

 <div class="card text-white bg-secondary m-5 p-3">



 <div>
    <p class="mt-4" style='font-size:3vw;'>Your Profile</p>
</div>

<div>
<!-- <i style='font-size:10vw;' class='fas text-white'>&#xf406;</i> -->
<i class="far fa-9x fa-user"></i>
</div>

<div class="mt-5">
<?php 
require ('profile-system/db_conn.php');
$name=$_SESSION['user_name'];
$sql ="SELECT * FROM users WHERE user_name='$name'";
$result =$conn->query($sql);
if($result){
    while($data = mysqli_fetch_assoc($result)){
        $user_name = $data['user_name'];
        $password = $data['password'];
        $email = $data['email'];
        $gender = $data['gender'];
        $address = $data['address'];
        $phone = $data['phone'];
    }
}

?>


    <h5>Username : <?php echo $user_name ?></h5>
    <h5>Email : <?php echo $email ?></h5>
    <h5>Password : <?php echo $password ?></h5>
    <h5>Gender : <?php echo $gender ?></h5>
    <h5>Address : <?php echo $address ?></h5>
    <h5>Phone : <?php echo $phone ?></h5>


</div>



 </div>


</body>
<?php include 'Extra/footer.php'; ?>
</html>