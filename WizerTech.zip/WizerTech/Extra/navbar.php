<?php 
session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/all.css">

 
  <title>navbar</title>
</head>
<body>



<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>









<nav class="navbar navbar-expand-lg navbar-dark bg-dark p-3">
  <div>
  <!-- <a class="navbar-brand" href="#">Navbar</a> -->
  </div>
  <a class="navbar-brand responsive" href="#">WizerTech</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

  


    <ul class="navbar-nav mr-auto">

    

      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="about.php">About Us</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="contactus.php">Contact Us</a>
      </li>



    <!-- this is dropdown-section -->


    <li class="nav-item">

<?php 
if (isset($_SESSION['id']) && isset($_SESSION['user_name'])){?>

<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <div>
         
          <i class="fas fa-user"></i>
          Profile
         </div>
        </a>
        <div class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">

          <a class="dropdown-item  text-white" href="viewprofile.php">View Profile</a>
          <a class="dropdown-item  text-white" href="profile-system/update-profile.php">Edit Profile</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item  text-white" href="teampage.php">Creator of this site</a>
        </div>
  
<?php 
}
else{
  ?>

  <?php 
 } 
?>

</li>






      <li class="nav-item">

      <?php 
      if (isset($_SESSION['id']) && isset($_SESSION['user_name'])){?>
        <a class="nav-link" href="profile-system/logout.php">LogOut</a>
      <?php 
      }
      else{
        ?>
        <a class="nav-link" href="profile-system/loginpage.php">Login</a>
        <?php 
      }
?>
      
      </li>






<!-- this is mycart button section -->



<li class="nav-item position-absolute end-0 m-3">
     

     <div class="">
     
     <?php 
        if (isset($_SESSION['id']) && isset($_SESSION['user_name'])){
          
          $count=0;
          if(isset($_SESSION['cart']))
          {
            $count =count($_SESSION['cart']);
          }
          ?>
            <a href="mycart.php" class="btn btn-outline-info "> <i class="fas fa-cart-plus"></i>(<?php echo $count;?>)</a>
        </div>
     
        <?php 
     }
     else{
     ?>
     
     <?php 
     }
     ?>
     
     
     </li>

     </div>
</ul>


</div>
  
</nav>



  
</body>
</html>



