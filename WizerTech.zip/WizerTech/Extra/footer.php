<!DOCTYPE html>
<html lang="en">
<head>
	
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

    
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        <link type="text/css" rel="stylesheet" href="css/mystylesheet.css"/>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



</head>
<footer class="bg-dark text-white m-1">
<section class="news mt-5">

	<div class="container py-4">

		<hr>
        <!-- <p class="text-center">&copy; Copyright 2021. All Rights Reserved</p> -->
	</div>


    <div class="container">
  <div class="row ">
    <div class="col-sm">
      <div class="text-center">
          <h5>Customer Care</h5>
           <p><br>
            Help Center<br>
            How to Buy<br>
            Returns & Refunds<br>

          </p>

      </div>
    </div>
    <div class="col-sm">
     


    <div style="text-align:center;">
    
    <h5>STAY CONNECTED</h5>
    <a href="https://facebook.com/"><i class="fa fa-facebook-f" style="font-size:48px;color:grey"></i></a>

<a href="https://www.instagram.com/"><i class="fa fa-instagram m-4" style="font-size:48px;color:grey"></i></a>

<a href="https://twitter.com/"><i class="fa fa-twitter" style="font-size:48px;color:grey"></i></a>
     
      </div>

      <div>
      <p class="text-center">&copy; Copyright 2021. All Rights Reserved</p>
      </div>


    </div>

    
    <div class="col-sm">
      <div class="container text-center ">
      <h5 class="">Payment Method</h5><br>

      <div class="container">
  <div class="row">
    <div class="col-sm">
    <p><i class="fab fa-3x fa-cc-mastercard "></i></p>
    </div>
    <div class="col-sm">
    <p><i class="fab fa-3x fa-cc-visa "></i></p>
    </div>
    <div class="col-sm">
    <i class="fab fa-3x fa-cc-paypal"></i>
    </div>
  </div>
</div>
     
      

      </div>
    </div>
  </div>
</div>

				
		
</section>
</footer>
</html>



