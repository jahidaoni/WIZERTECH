
<?php
$database_name = "Product_details";
$con = mysqli_connect("localhost","root","",$database_name);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/all.css">
    <title>Product</title>
</head>
<body>
  <div>
    <h1 class="p-3 mt-5   m-2 text-center">Popular Items</h1>
  </div>
   
    
<div class="container mt-5 ">
    <div class="row">

    <?php
            $table_name="product";
            $query = "SELECT * FROM product ORDER BY id ASC ";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {
                        
                    ?>

        <div class="col-lg-3 text-center">

          <form action="manage_cart.php" method="POST">
          
        <div class="card mt-5 text-center" style="border:none; box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;">
          <img src="images/<?php echo $row["image"]; ?>" style="height:20vw;width:20vw;" class="card-img-top responsive" alt="...">
           <div class="card-body text-center">
           <h5 class="card-title"><?php echo $row["pname"]; ?></h5>
           <p class="card-text">Price: <?php echo $row["price"]; ?></p>
           <?php 
            if (isset($_SESSION['id']) && isset($_SESSION['user_name'])){?>
           <button type='submit' class="btn btn-info text-white" name="Add_To_Cart">Add To Cart <i class="fas fa-cart-plus"></i></button>
           
           <?php
           }
           ?>
           <button type='submit' class="btn btn-info text-white" name="Add_To_Detail">Details <i class="fas fa-info-circle"></i></button>

           <input type="hidden" name="Item_Name" value="<?php echo $row["pname"]; ?>">
           <input type="hidden" name="Price" value="<?php echo $row["price"]; ?>">
           <input type="hidden" name="Db_Name" value="<?php echo $database_name; ?>">
           <input type="hidden" name="Table_Name" value="<?php echo $table_name; ?>">
           </div>
           </div>
           
           </form>
           
        </div>

        <?php
              }
            }
        ?>
        
    </div>
</div>

</body>
</html>