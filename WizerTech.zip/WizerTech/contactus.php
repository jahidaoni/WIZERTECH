<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
  $name=$_POST['user_name'];
  $email=$_POST['email'];
  $message=$_POST['message'];


$server="localhost";
$username="root";
$password="";
$dbname="connection_db";

$conn =mysqli_connect($server,$username,$password,$dbname);


if(!$conn){
  die("sorry we failed to connect: ".mysqli_connect_error());
}
else{
  // echo "Connection Was successful<br>";

  $sql= "INSERT INTO `user_message` ( `user_name`, `email`, `message`) VALUES ( '$name', '$email', '$message')";

  $result = mysqli_query($conn,$sql);

  if($result){
    // echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    // <strong>Success!</strong> Your entry has been submitted successfully!
    // <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    // <span aria-hidden="true">$times;</span>
    // </button>
    // </div>';
  }
  else{
    echo "The record was not inserted successfully because of this error --->". mysqli_error($conn);
  }
}

}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/all.css">
     
    
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


</head>
<body>

<div>
<?php include 'Extra/navbar.php'; ?>
</div>

<div>
    <h2 class="text-center m-4">Our Location</h2>
     <div class="m-2 ">
     <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14608.957345960143!2d90.3855965!3d23.7388432!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x12b9ec0f1c8e7b03!2sMultiplan%20Center!5e0!3m2!1sen!2sbd!4v1633028593618!5m2!1sen!2sbd" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
     </div>
</div>




<!-- our contact info section -->

<div class="bg-dark p-5">
    <div>
        <br>
    <h2 class="text-center text-white">Our Contact Info</h2>
    <br><br>
    </div>

<div class="container text-center">
  <div class="row">
    <div class="col-sm">
    <div class="card" style="width: 18rem;border:none;box-shadow: rgba(240, 46, 170, 0.4) 5px 5px, rgba(240, 46, 170, 0.3) 10px 10px, rgba(240, 46, 170, 0.2) 15px 15px, rgba(240, 46, 170, 0.1) 20px 20px, rgba(240, 46, 170, 0.05) 25px 25px;">
    
  <div class="card-body">
    <h4 class="card-title">Address</h4>
    <i class="fas fa-2x fa-map-marker-alt"></i>
    <p class="card-text">6th floor, 28 Kazi Nazrul Islam Ave,Navana Zohura Square, Dhaka 1000</p>
    
  </div>
</div>
    </div>
    <div class="col-sm">
    <div class="card" style="width: 18rem;border:none;box-shadow: rgba(240, 46, 170, 0.4) 5px 5px, rgba(240, 46, 170, 0.3) 10px 10px, rgba(240, 46, 170, 0.2) 15px 15px, rgba(240, 46, 170, 0.1) 20px 20px, rgba(240, 46, 170, 0.05) 25px 25px;">
  
  <div class="card-body">
    <h4 class="card-title">Email</h4>
    <div class="p-2">
    <i class="fas fa-2x fa-envelope-open-text"></i>
    <p class="card-text">info.webteam@wizertechbd.com</p><br>
    </div>
    
  </div>
</div>
    </div>
    <div class="col-sm">
    <div class="card" style="width: 18rem;border:none;box-shadow: rgba(240, 46, 170, 0.4) 5px 5px, rgba(240, 46, 170, 0.3) 10px 10px, rgba(240, 46, 170, 0.2) 15px 15px, rgba(240, 46, 170, 0.1) 20px 20px, rgba(240, 46, 170, 0.05) 25px 25px;">
  
  <div class="card-body">
    <h4 class="card-title">Support</h4><br>
    <i class="fas fa-2x fa-phone"></i>
    <h3>0987-0258</h3>
   
  </div>
</div>
    </div>
  </div>
</div>
</div>



<!-- Sales Outlets section -->


<div class="text-center bg-dark mt-4">
    <div>
        <br><br>

        <h2 class="text-white">Sales Outlets </h2>
        <br><br>
    </div>


<div class="container p-5">
  <div class="row">
    <div class="col-sm">
    <div class="card bg-info" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item bg-info text-white"><h4>Banani Branch</h4><br></li>
    <li class="list-group-item bg-info text-white">
156 Concord Colosseum, 1st Floor, Road# 12, Kemal Ataturk Ave, Dhaka.</li>

    <li class="list-group-item bg-info text-white">Desktop: 01709995413 <br>
Laptop: 01709995408</li>

    <li class="list-group-item bg-info text-white">Open Everyday</li>
  </ul>
</div>

    </div>



    <div class="col-sm">
    <div class="card bg-info" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item bg-info text-white"><h4>Multiplan RIG House</h4><br></li>
    <li class="list-group-item bg-info text-white">
    Shop-942-944, Level-09, Multiplan Center, New Elephant Road, Dhaka-1205</li>

    <li class="list-group-item bg-info text-white">Desktop: 01313717021<br>
</li>

    <li class="list-group-item bg-info text-white">Tuesday Closed</li>
  </ul>
</div>

    </div>



    <div class="col-sm">
    <div class="card bg-info" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item bg-info text-white"><h4>Multiplan Branch - (Level-09)</h4><br></li>
    <li class="list-group-item bg-info text-white">
    Shop-934-935, Level-09, Multiplan Center, New Elephant Road, Dhaka</li>

    <li class="list-group-item bg-info text-white">Laptop: 01709995422 <br>
</li>

    <li class="list-group-item bg-info text-white">Tuesday Closed</li>
  </ul>
</div>

    </div>
   
  </div>
</div>








<div class="container p-5">
  <div class="row">
    <div class="col-sm">
    <div class="card bg-info" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item bg-info text-white"><h4>Uttara Branch</h4><br></li>
    <li class="list-group-item bg-info text-white">
156 Concord Colosseum, 1st Floor, Road# 12, Kemal Ataturk Ave, Dhaka.</li>

    <li class="list-group-item bg-info text-white">Desktop: 01709995413 <br>
Laptop: 01709995408</li>

    <li class="list-group-item bg-info text-white">Open Everyday</li>
  </ul>
</div>

    </div>



    <div class="col-sm">
    <div class="card bg-info" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item bg-info text-white"><h4>Gazipur Branch</h4><br></li>
    <li class="list-group-item bg-info text-white">
    Shop-942-944, Level-09, Multiplan Center, New Elephant Road, Dhaka-1205</li>

    <li class="list-group-item bg-info text-white">Desktop: 01313717021<br>
</li>

    <li class="list-group-item bg-info text-white">Tuesday Closed</li>
  </ul>
</div>

    </div>



    <div class="col-sm">
    <div class="card bg-info" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item bg-info text-white"><h4>IDB Branch</h4><br></li>
    <li class="list-group-item bg-info text-white">
    Shop-934-935, Level-09, Multiplan Center, New Elephant Road, Dhaka</li>

    <li class="list-group-item bg-info text-white">Laptop: 01709995422 <br>
</li>

    <li class="list-group-item bg-info text-white">Tuesday Closed</li>
  </ul>
</div>

    </div>

  </div>
</div>

</div>




<!-- sent us message section -->

<?php 
        if (isset($_SESSION['id']) && isset($_SESSION['user_name'])){
        
          ?>

<?php 
require ('profile-system/db_conn.php');
$name=$_SESSION['user_name'];
$sql ="SELECT * FROM users WHERE user_name='$name'";
$result =$conn->query($sql);
if($result){
    while($data = mysqli_fetch_assoc($result)){
        $user_name = $data['user_name'];
        $email = $data['email'];
        
    }
}

?>


<div class="container bg-dark text-white mt-5 rounded">
<br><br>
<h2 class="text-center container">Please Enter Your Concerns Here.....</h2><br>
<div class="text-center container">
<i class="fas fa-4x fa-exclamation"></i>
<i class="fas fa-4x fa-exclamation"></i>
<i class="fas fa-4x fa-exclamation"></i>
</div>
<form action="contactus.php"  method="post" class="m-5">

<div class="form-group p-3">
    <label for="name">User Name</label>
    <input type="text" class="form-control" name="user_name" id="user_name" aria-describedby="emailHelp" value="<?php echo $user_name ?>">

    
  </div>


  <div class="form-group p-3">
    <label for="exampleInputEmail1">Email address</label>
    
    <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo $email ?>">
    
    
  </div>

  <!-- <div class="form-group p-3">
    <label for="message">Message</label>
    
    <input type="text" class="form-control " name="message" id="message" aria-describedby="emailHelp" placeholder="Enter your message here ">
    
  </div> -->


  <div class="form-group p-3">
    <label for="exampleFormControlTextarea1">Enter Your Message</label>
    <textarea class="form-control"  name="message" id="message" rows="3" placeholder="Enter your message here..."></textarea>
  </div>


  
  <button type="submit" class="btn btn-primary m-3">Submit</button>
</form>


</div>
<?php 
     }
     else{
     ?>
     
     <?php 
     }
     ?>
    
</body>

<?php include 'Extra/footer.php'; ?>
</html>