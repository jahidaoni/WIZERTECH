<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/all.css">
     
    
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    


    

</head>
<body>
<?php include 'Extra/navbar.php'; ?>

<div class="mt-4">
<div class=" container bg-dark text-white p-5 text-center">
    <h2>About WizerTech</h2>
    <p>Wizer Tech has been founded on 1 March 2007. From then to now, Wizer Tech has won the heart of many people and now is a country-wide renowned brand. That has been possible due to the hard work Wizer Tech has done to satisfy its customers. Having the aim to satisfy customers, providing customers with their required products, and being true to their motto, “Customers Come First,” has brought Wizer Tech to the top of the E-Commerce Site and also is one of the largest Computer and Technology product retailers. Wizer Tech has over 300 employees and is growing more and more, working diligently to fulfill the Main Criteria of Wizer Tech’s Motto or Vision. Wizer Tech is located in 4 central territories, Dhaka, Gazipur, Chattogram, Khulna, and Rangpur, and has 13 outlets from where you can get your desired tech products. There are nine outlets in Dhaka alone because Dhaka is the capital city, there is one outlet in Gazipur, one outlet in Chattogram, one outlet in Khulna, and the final outlet is in Rangpur.</p>
</div>

<div class=" container bg-dark text-white p-5 text-center">
    <h2>The Main Goal and Aim</h2>
    <p>We are Wizer Tech, and we are here to help you with all your technology needs. We aim to provide all the requirements of our customers and help them satisfy their needs, wants, and desires. We delight in seeing our customers happy and satisfied with our resiliency in providing them with their products. Our complete focus is on the customers. We keep tabs and records on what our customers want, and we try our level best to bring that for them. We are already providing our customers with the delivery system so that they can order online and receive their products from their area. They do not have to travel long distances to get their desired product.</p>
</div>

<div class=" container bg-dark text-white p-5 text-center">
    <h2>Services Being Provided</h2>
    <p>We are a Tech-based product seller. We are providing our customers with the best quality products at the most reasonable price. We have varieties of products that our customers can choose from. The product range starts from Desktop PC, Laptop & Netbook, UPS, Tablet PC, Monitors, Office Equipment, Camera, Security Camera, Television and many other products. Each of our products is checked and reviewed before it is sold to our Loyal Customers. You are our driving force to better ourselves in all the aspects of the service-providing sector. We strive to become a Perfectionist Company that delivers everything, word for word.</p>
</div>

<div class=" container bg-dark text-white p-5 text-center">
    <h2>Customer Satisfaction</h2>
    <p>We have been in the market for a long time, and we have come to know what the customers want and desire. We have made changes around our customers so that we will be able to fulfill the desires of each of our customers. We want to improve more and more to be able to give everyone their desired or dreamed products. We are providing online buying opportunities for our customers, providing delivery service for all of our products all over Bangladesh. We provide the best after sells customer service to our customers to make them feel that we do care about their possession and provide them with the best solutions for their problems.</p>
</div>

<div class=" container bg-dark text-white p-5 text-center">
    <h2>The Brand That Cares For You</h2>
    <p>This is Wizer TECH! A Brand that is Truly concerned about its customers and loyally provides all the needs of the customers. Customers come first to this Company. Our customers will receive the best service and deals that Wizer Tech offers. To us, our customer’s wants and needs take the top priority. We always have and will aim to provide the perfect result to our loyal customers. And our after-sales service will ensure that no one of our customers will come to us with the same issue twice. Come and Experience the service, product, and facilities Wizer Tech offers.</p>
</div>

</div>
</body>
<?php include 'Extra/footer.php'; ?>
</html>