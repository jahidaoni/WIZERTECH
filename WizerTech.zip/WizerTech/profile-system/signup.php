<!DOCTYPE html>
<html>
<head>
	<title>SIGN UP</title>
	<link rel="stylesheet" type="text/css" href="profile-style.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
     <link rel="stylesheet" href="../css/all.css">
</head>
<body style="background-image: url('../images/signup1.jpg');">
     <form action="signup-check.php" method="post">
             <h2 class="">SIGN UP</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

         
          <div class="form-group">
          <label>User Name</label>
          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      class="form-control"
                      name="uname" 
                      placeholder="User Name"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      class="form-control"
                      name="uname" 
                      placeholder="User Name"><br>
          <?php }?>
          </div>
             
          <div class="form-group">
          <label>Email</label>
          <?php if (isset($_GET['email'])) { ?>
               <input type="text" class="form-control" 
                      name="email" 
                      placeholder="Email"
                      value="<?php echo $_GET['email']; ?>"><br>
          <?php }else{ ?>
               <input type="text"
                      class="form-control" 
                      name="email" 
                      placeholder="Email"><br>
          <?php }?>
          </div>
         
          <!-- <label>Gender</label>
     	<input type="text"
                 class="form-control" 
                 name="gender" 
                 placeholder="Gender"><br>

          </div>

          <label>Address</label>
     	<input type="text"
                 class="form-control" 
                 name="address" 
                 placeholder="Address"><br>

          </div>

          <label>Phone</label>
     	<input type="text"
                 class="form-control" 
                 name="phone" 
                 placeholder="Phone"><br>

          </div>
           -->

          <label>Password</label>
     	<input type="password"
                 class="form-control" 
                 name="password" 
                 placeholder="Password"><br>

          </div>

          <div class="form-group">
           <label>Re Password</label>
          <input type="password"
                 class="form-control" 
                 name="re_password" 
                 placeholder="Re_Password"><br>
           </div> 

     	
     	<!-- <button type="submit" class="btn btn-secondary text-white">Sign Up <i class="fas fa-user-plus"></i></button> -->

          <div class="pb-5">
          <button type="submit" class="bg-secondary rounded form-control text-white">Sign Up <i class="fas fa-user-plus"></i></button>
          </div>
         

          <div class="mt-2">
          <a href="../index.php" class="ca bg-secondary rounded form-control text-white text-center "> Home <i class="fas fa-home"></i></a>
          </div>


         

          <div class="text-center">
          <a href="loginpage.php" class="ca text-center mt-2">Already have an account?</a>
          </div>
     </form>
     
</body>
</html>