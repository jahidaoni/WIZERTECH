<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Profile</title>
	<link rel="stylesheet" type="text/css" href="profile-style.css">
	<link rel="stylesheet" href="../css/all.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>
<body style="background-image: url('../images/signup1.jpg');">

    <form action="update-p.php" method="post">
		<br><br>
		<br><br>
		<br><br>
	<h2>Update Profile</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

     	<?php if (isset($_GET['success'])) { ?>
            <p class="success"><?php echo $_GET['success']; ?></p>
        <?php } ?>

     	<label class="form-label">Old Password</label>
     	<input type="password" 
     	       name="op" 
				class="form-control"
     	       placeholder="Old Password">
     	       <br>

     	

     	<label class="form-label">Confirm New Password</label>
     	<input type="password" 
     	       name="c_np" 
				class="form-control"
     	       placeholder="Confirm New Password">
     	       <br>

				<label class="form-label">New Email</label>
     	         <input type="text" 
     	         name="n_email" 
				  class="form-control"
     	         placeholder="New Email">
     	       <br>


                 <div class="form-group">
				<label class="form-label">Gender</label>
     	        <input type="text"
                 class="form-control" 
                 name="gender" 
                 placeholder="Gender"><br>

          </div>

          

            <div class="form-group">
			<label class="form-label">Address</label>
     	       <input type="text"
                 class="form-control" 
                 name="address" 
                 placeholder="Address"><br>
			</div>

            <div class="form-group">
			<label class="form-label">Phone</label>
     	         <input type="text"
                 class="form-control" 
                 name="phone" 
                 placeholder="Phone"><br>

          </div>
			</div>
          

     	<div class="pb-5">
		 <button type="submit" class="bg-secondary rounded form-control text-white text-center">CHANGE</button>
		 </div>
          <!-- <a href="../index.php" class="ca">Home<i class="fas fa-home"></i></a> -->

		  <div class="mt-2">
          <a href="../index.php" class="ca bg-secondary rounded form-control text-white text-center "> Home <i class="fas fa-home"></i></a>
          </div>
     </form>
</body>
</html>

<?php 
}else{
     header("Location: loginpage.php");
     exit();
}
 ?>