 <!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="profile-style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="../css/all.css">
	
</head>
<body class='bg-secondary' style="background-image: url('../images/signup1.jpg');">
     <div class="">
	 
	 <form action="login.php" method="post" class="responsive">
     	<h2>LOGIN</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

		 

     	<label class="form-label">User Name</label>
     	<input type="text"class="form-control" name="uname" placeholder="User Name"><br>
		 

		
     	<label class="form-label">Password</label>
     	<input type="password" class="form-control" name="password" placeholder="Password"><br>
		

		 
     	<div class="pb-5">
		 <button type="submit" class="bg-secondary rounded form-control text-white">Login <i class="fas fa-sign-in-alt"></i></button>
		 </div>
		 
          

		  <!-- <a href="../index.php" class="ca bg-secondary rounded text-white form-control text-center">Home <i class="fas fa-home"></i></a> -->

		  <div class="mt-2">
          <a href="../index.php" class="ca bg-secondary rounded form-control text-white text-center "> Home <i class="fas fa-home"></i></a>
          </div>
		 
			 
		  <div class="text-center">

		  <a href="signup.php"class="ca">Create An Account</a>
		  </div>
		  
     </form>
	 </div>
	 
	 
	 </div>
</body>
</html> 
















