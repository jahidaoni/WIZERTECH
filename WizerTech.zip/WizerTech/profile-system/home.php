<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>profile-home</title>
	<link rel="stylesheet" type="text/css" href="profile-style.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
     <link rel="stylesheet" href="../css/all.css">

</head>
<body class="bg-dark" style="background-image: url('../images/signup1.jpg');">
     <div>
     <h1 class="m-5">Hello, <?php echo $_SESSION['user_name']; ?></h1>



     <!-- <nav class="home-nav m-3">
     	<a href="update-profile.php" class="m-3">Update Profile</a>
        <a href="logout.php" class="m-3">Logout</a>
     </nav>
     </div>

     <div class="mt-3 p-5">
     <nav class="home-nav m-3">
     	<a href="../index.php">Go To Home Page</a>
        
     </nav>
     </div> -->



<div>
 
<a href="logout.php"><button type="button" class="btn btn-light px-5 m-3"><h3>Logout</h3> <i class="fas fa-2x fa-sign-out-alt"></i></button></a>


     <a href="update-profile.php"><button type="button" class="btn btn-light px-5 m-3"><h3>Update Profile</h3> <i class="fas fa-2x fa-user-circle"></i></button></a>
     

     <a href="../index.php"><button type="button" class="btn btn-light px-5 m-3"><h3>Home</h3> <i class="fas fa-home fa-2x"></i></button></a>
     
</div>
  



<!-- <div class="container text-center">
  <div class="row">
    <div class="col">
    <a href="../index.php"><button type="button" class="btn btn-light px-5 "><h3>Home</h3> <i class="fas fa-home fa-2x"></i></button></a>
    </div>
    <div class="col">
    <a href="update-profile.php"><button type="button" class="btn btn-light px-5 "><h3>Update Profile</h3> <i class="fas fa-2x fa-user-circle"></i></button></a>
    </div>
    <div class="col">
    <a href="logout.php"><button type="button" class="btn btn-light px-5 "><h3>Logout</h3> <i class="fas fa-2x fa-sign-out-alt"></i></button></a>
    </div>
  </div>
</div> -->



  
</body>
</html>

<?php 
}else{
     header("Location: loginpage.php");
     exit();
}
 ?>