<?php include("Extra/navbar.php");?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>congratulations-page</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/all.css">
 


</head>
<body>
<div class="container">
    <?php
    if($_SESSION['cart']){
    
    ?>
<div class="row"style=" text-align: center;">
    <img src="images/congratulations_image_gif.gif" style=" height:35vw;" alt="">
    </div>

    <div class="row  bg-dark rounded text-white p-5 m-3" style=" text-align: center;">
        <h2>Your order has been placed. Thanks for shopping from us...</h2>
    </div>


</div>

<?php
}
else{
 ?>

<div class="row  bg-dark rounded text-white p-5 m-3" style=" text-align: center;">
        <h2>We are very sorry we cound't match your expectatons...</h2>
    </div>
    <div class="row"style=" text-align: center;">
    <img src="images/sorry.gif" style=" height:30vw;" alt="">
    </div>
    <?php
    }
    ?>

</body>
</html>