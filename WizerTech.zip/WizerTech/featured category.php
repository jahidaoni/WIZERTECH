<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/all.css">
    <title>Document</title>
</head>
<body>

<div>
    <h1 class="p-3 mt-5  m-2 text-center">Featured Category</h1>
  </div>

<div class="container text-center">
  <div class="row m-5">
    <div class="col">
    <a  href="monitor.php" style="color: black;">
    <div class='card' style="border:none;">
    <i class="fas fa-5x fa-desktop"></i>
    <div class="card-body">
    <h5 class="card-title">Monitor</h5>
  </div>

    </div>
    </a>
    </div>
    <div class="col">
    <a  href="keyboard.php" style="color: black;">
    <div class='card'style="border:none;">
    <i class="fas fa-5x fa-keyboard"></i>
    <div class="card-body">
    <h5 class="card-title">Keyboard</h5>
  </div>
    </div>
    </a>

    </div>
    <div class="col">
    <a  href="mouse.php"style="color: black;">
    <div class='card'style="border:none;">
    <i class="fas fa-5x fa-mouse"></i>
    <div class="card-body">
    <h5 class="card-title">Mouse</h5>
  </div>
    </div>
    </a>
    </div>
    
  </div>
  <div class="row mx-5">
    <div class="col">
      
    <a  href="headphone.php"style="color: black;">
    <div class='card'style="border:none;">
    <i class="fas fa-5x fa-headphones"></i>
    <div class="card-body">
    <h5 class="card-title">HeadPhones</h5>
  </div>
    </div>
    </a>

    </div>
    <div class="col">
    
    <a  href="laptop.php"style="color: black;">
    <div class='card'style="border:none;">
    <i class="fas fa-5x fa-laptop"></i>
    <div class="card-body">
    <h5 class="card-title">Laptop</h5>
  </div>
    </div>
    </a>

    </div>
    <div class="col">
    
    <a  href="camera.php"style="color: black;">
    <div class='card'style="border:none;">
    <i class="fas fa-5x fa-camera"></i>
    <div class="card-body">
    <h5 class="card-title">Camera</h5>
  </div>
    </div>
    </a>

    </div>
  </div>
</div>
    

</body>
</html>