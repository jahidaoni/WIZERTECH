
<?php
$database_name = "connection_db";
$con = mysqli_connect("localhost","root","",$database_name);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/all.css">
    <title>monitor</title>
</head>
<body class="bg-dark">
  <div>
  <?php include 'Extra/navbar.php'; ?>
  </div>
  <div class="text-center mt-5">
  <i class="fas fa-5x fa-user-friends text-white"></i>
    <h2 class="text-white text-center">Members who worked on this project are</h2>
    
  </div>
   
    
<div class="container mt-5 ">
    <div class="row">

    <?php
            $query = "SELECT * FROM group_member ORDER BY id ASC ";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {
                        
                    ?>
               <div class="">
                  
                    
                   <div class="card mb-3" style="max-width: 1000px;border:none;">
                    <div class="row g-0">
                        <div class="col-md-4">
                      <img src="images/<?php echo $row["image"]; ?>" class="img-fluid rounded-start" alt="...">
                      </div>
                         <div class="col-md-8">
                      <div class="card-body">
                      <h5 class="card-title">Name: <?php echo $row["name"]; ?></h5>
                       <p class="card-text">Email: <?php echo $row["email"]; ?></p>
                       <p class="card-text">Phone No: <?php echo $row["phone"]; ?></p>
                       <p class="card-text">Address: <?php echo $row["address"]; ?></p>
                       <p class="card-text"><small class="text-muted">stay connected at:</small></p>
                       <div>
                       <i class="fab fa-3x fa-facebook m-2"style="color:blue;"></i>
                       <i class="fab fa-3x fa-instagram m-2"style="color:red;"></i>
                       <i class="fab fa-3x fa-twitter m-2"style="color:blue;"></i>
                       </div>
                   
      </div>
    </div>
  </div>
</div>
                  

                 
               </div>
            
        <?php
              }
            }
        ?>
        
    </div>
</div>

</body>

<?php include 'Extra/footer.php'; ?>

</html>